﻿namespace SocialService.API.Models.DTO
{
    public class FirebaseSettings
    {
        public string BucketName { get; set; } = null!;
        public string CredentialPath { get; set; } = null!;
    }
}
